package com.shruti.app.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.shruti.app.Models.User;
import com.shruti.app.exceptions.ResourceNotFoundException;
import com.shruti.app.repositories.UserRepository;

@RestController
public class UserController {

	private UserRepository userRepository;
	
	@Autowired
	public UserController(UserRepository userRepository) {
		this.userRepository=userRepository;
	}
	
	@PostMapping("/user/save")
	public User saveUser(@RequestBody User user) {
		return this.userRepository.save(user);
	}
	
	@GetMapping("user/All")
	public ResponseEntity<List<User>> getUsers(){
		return ResponseEntity.ok(
			this.userRepository.findAll()
		);
	}
	
	@DeleteMapping("/user/{id}")
	public ResponseEntity<Void> removeUser(@PathVariable(value="id") String id){
		User user = this.userRepository.findById(id)
				.orElseThrow(
						() -> new ResourceNotFoundException("User Not Found")
						);
		this.userRepository.delete(user);
		return ResponseEntity.ok().build();
	}
	
	
	@GetMapping("/user/{id}")
	public ResponseEntity<User> getUser(@PathVariable(value = "id") String id){
		User user = this.userRepository.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("User Not Found")
				);
		return ResponseEntity.ok().body(user);
	
	}
}
